# leaf year

"""




"""
def isleafyear(year):
  if (year % 4 == 0 and year % 100 != 0):
    return True
  else:
    return False

year = int(input("Enter a year : "))

if isleafyear(year):
  print('{} is a leaf year.'.format(year))
else:
  print('{} is not leaf year.'.format(year))